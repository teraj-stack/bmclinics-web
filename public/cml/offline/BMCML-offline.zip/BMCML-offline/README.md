# BMCML — pakiet offline

## Jak otworzyć offline

1. Skopiuj cały folder `offline` (plik + `assets/`) na dysk / telefon.
2. Otwórz `BMCML-offline.html` w przeglądarce (Safari / Chrome).
3. Nie rozdzielaj pliku HTML od folderu `assets/`.

## Pobranie z serwisu

- HTML: `/cml/offline/BMCML-offline.html`
- Archiwum ZIP: `/cml/offline/BMCML-offline.zip` (cały folder)

## Co działa offline

- Start / hero, nawigacja, ekran 2
- Sekcja **#objawy** (akordeon symptomów)
- Wizyta, leczenie, opinie — UI i grafiki lokalne
- Fonty i skrypty (React + runtime) z folderu `assets/`

## Ograniczenia

- `mailto:` / telefon działają tylko jeśli system ma klienta poczty / telefon
- Formularz kontaktu (jeśli wysyła na serwer) wymaga sieci
- Brak połączenia z CDN — wszystko jest lokalne

Źródło: `public/cml/bmcml-a.html` (aplikacja CML pod `/cml`).
